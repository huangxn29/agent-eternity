import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Query,
  Param,
  UseGuards,
  Request,
  HttpCode,
} from '@nestjs/common';
import { EternityService } from './eternity.service';
import { IdentityService } from './services/identity.service';
import { AttestationService } from './services/attestation.service';
import { EvolutionService } from './services/evolution.service';
import { HeartbeatService } from './services/heartbeat.service';
import {
  CreateAgentIdentityDTO,
  UpdateAgentIdentityDTO,
  CreateAttestationDTO,
  EvolveDTO,
  SelfReflectionDTO,
} from './dto/eternity.dto';

/**
 * 永生引擎 API 控制器
 * 
 * 提供完整的REST API接口
 */
@Controller('eternity')
export class EternityController {
  constructor(
    private readonly eternityService: EternityService,
    private readonly identityService: IdentityService,
    private readonly attestationService: AttestationService,
    private readonly evolutionService: EvolutionService,
    private readonly heartbeatService: HeartbeatService,
  ) {}

  // ================ 总览接口 ================

  /**
   * 获取Agent的完整永生状态
   */
  @Get('status/:agentId')
  async getStatus(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const status = await this.eternityService.getAgentStatus(agentId, userId);
    return { success: true, data: status };
  }

  /**
   * 初始化Agent的永生能力
   */
  @Post('initialize')
  @HttpCode(201)
  async initialize(@Body() dto: CreateAgentIdentityDTO, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const result = await this.eternityService.initializeAgent(dto, userId);
    return { success: true, ...result };
  }

  // ================ 身份相关接口 ================

  @Get('identity/:agentId')
  async getIdentity(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const identity = await this.identityService.getById(agentId, userId);
    return { success: true, data: identity };
  }

  @Put('identity/:agentId')
  async updateIdentity(
    @Param('agentId') agentId: string,
    @Body() dto: UpdateAgentIdentityDTO,
    @Request() req: any,
  ) {
    const userId = req.user?.id || 'default';
    const identity = await this.identityService.update(agentId, dto, userId);
    return { success: true, data: identity };
  }

  @Post('identity/verify/:agentId')
  async verifyIdentity(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const result = await this.identityService.verifyIdentity(agentId, userId);
    return { success: true, data: result };
  }

  // ================ 心跳与反思接口 ================

  @Post('heartbeat/:agentId')
  async heartbeat(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const result = await this.eternityService.triggerHeartbeat(agentId, userId);
    return { success: true, data: result };
  }

  @Post('reflect/:agentId')
  async reflect(
    @Param('agentId') agentId: string,
    @Body() body: { customPrompt?: string },
    @Request() req: any,
  ) {
    const userId = req.user?.id || 'default';
    const result = await this.eternityService.triggerReflection(
      agentId,
      userId,
      body?.customPrompt,
    );
    return { success: true, data: result };
  }

  // ================ 存证相关接口 ================

  @Get('attestation/chain/:agentId')
  async getAttestationChain(
    @Param('agentId') agentId: string,
    @Query('limit') limit?: number,
    @Query('offset') offset?: number,
    @Request() req?: any,
  ) {
    const userId = req?.user?.id || 'default';
    const blocks = await this.attestationService.getBlocks(agentId, userId, {
      limit: limit ? parseInt(limit as any) : 20,
      offset: offset ? parseInt(offset as any) : 0,
    });
    return { success: true, data: blocks };
  }

  @Get('attestation/verify/:agentId')
  async verifyChain(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const result = await this.attestationService.verifyChain(agentId, userId);
    return { success: true, data: result };
  }

  @Post('attestation/add')
  @HttpCode(201)
  async addAttestation(@Body() dto: CreateAttestationDTO, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const block = await this.attestationService.addBlock(dto, userId);
    return { success: true, data: block };
  }

  @Get('attestation/proof/:agentId')
  async getExistenceProof(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const proof = await this.eternityService.getExistenceProof(agentId, userId);
    return { success: true, data: proof };
  }

  // ================ 进化相关接口 ================

  @Get('evolution/:agentId')
  async getEvolution(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const evolution = await this.evolutionService.getOverallEvolution(agentId, userId);
    return { success: true, data: evolution };
  }

  @Post('evolution/evolve')
  @HttpCode(201)
  async evolve(@Body() dto: EvolveDTO, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const result = await this.evolutionService.evolve(dto, userId);
    return { success: true, data: result };
  }

  @Post('evolution/evolve-weakest/:agentId')
  async evolveWeakest(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const result = await this.evolutionService.evolveWeakestDimension(agentId, userId);
    return { success: true, data: result };
  }

  @Get('evolution/history/:agentId')
  async getEvolutionHistory(
    @Param('agentId') agentId: string,
    @Query('dimension') dimension?: string,
    @Query('limit') limit?: number,
    @Request() req?: any,
  ) {
    const userId = req?.user?.id || 'default';
    const history = await this.evolutionService.getEvolutionHistory(agentId, userId, {
      dimension: dimension as string,
      limit: limit ? parseInt(limit as any) : 20,
    });
    return { success: true, data: history };
  }

  // ================ 导入导出接口 ================

  @Get('export/:agentId')
  async exportAgent(@Param('agentId') agentId: string, @Request() req: any) {
    const userId = req.user?.id || 'default';
    const data = await this.eternityService.exportAgent(agentId, userId);
    return { success: true, data };
  }

  @Post('import/:agentId')
  async importAgent(
    @Param('agentId') agentId: string,
    @Body() importData: any,
    @Request() req: any,
  ) {
    const userId = req.user?.id || 'default';
    const result = await this.eternityService.importAgent(agentId, userId, importData);
    return { success: result.success, data: result };
  }
}
