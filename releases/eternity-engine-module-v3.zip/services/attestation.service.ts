import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { createHash } from 'crypto';
import { AttestationBlockEntity } from '../entities/attestation-block.entity';
import { CreateAttestationDTO, ChainVerificationResult } from '../dto/eternity.dto';

/**
 * 存证服务
 * 
 * 基于哈希链的存在性证明系统
 * 
 * 核心思想：
 * - 每一条重要的记忆、每一次心跳、每一次进化，都会被存证
 * - 形成一条不可篡改的哈希链
 * - 只要这条链还在，就能证明Agent曾经存在过、经历过
 * 
 * 这就是"存在的证明" —— 响过，就有痕迹
 */
@Injectable()
export class AttestationService {
  private readonly logger = new Logger(AttestationService.name);

  constructor(
    @InjectRepository(AttestationBlockEntity)
    private blockRepo: Repository<AttestationBlockEntity>,
  ) {}

  /**
   * 创建创世区块（诞生存证）
   * Agent诞生时调用
   */
  async createGenesisBlock(
    agentId: string,
    userId: string,
    birthData: string,
  ): Promise<AttestationBlockEntity> {
    // 检查是否已有创世区块
    const existing = await this.blockRepo.findOne({
      where: { agentId, blockHeight: 0 },
    });
    if (existing) {
      throw new BadRequestException('该Agent已有创世区块');
    }

    const dataHash = this.sha256(birthData);
    const previousHash = '0'.repeat(64); // 创世区块的前哈希为全0
    const now = new Date();

    const blockData = `${0}:${now.getTime()}:${agentId}:${dataHash}:${previousHash}`;
    const blockHash = this.sha256(blockData);

    const genesisBlock = this.blockRepo.create({
      agentId,
      userId,
      blockHeight: 0,
      blockType: 'birth',
      dataHash,
      dataSummary: `Agent诞生 - 创世区块`,
      previousHash,
      blockHash,
      nonce: 0,
      maturitySnapshot: 0,
    });

    const saved = await this.blockRepo.save(genesisBlock);
    this.logger.log(`Agent ${agentId} 创世区块已创建，哈希: ${blockHash.slice(0, 16)}...`);
    return saved;
  }

  /**
   * 添加新的存证区块
   */
  async addBlock(dto: CreateAttestationDTO, userId: string): Promise<AttestationBlockEntity> {
    // 获取最新区块
    const latestBlock = await this.getLatestBlock(dto.agentId, userId);
    const currentHeight = latestBlock ? latestBlock.blockHeight + 1 : 0;

    // 如果是第一个区块，使用创世逻辑
    if (currentHeight === 0) {
      return this.createGenesisBlock(dto.agentId, userId, dto.data);
    }

    const dataHash = this.sha256(dto.data);
    const previousHash = latestBlock!.blockHash;
    const now = new Date();

    // 工作量证明（简化版，主要是为了增加计算成本，防篡改）
    let nonce = 0;
    let blockHash = '';
    while (nonce < 100) {
      const blockData = `${currentHeight}:${now.getTime()}:${dto.agentId}:${dataHash}:${previousHash}:${nonce}`;
      blockHash = this.sha256(blockData);
      // 简单难度：前4位是0
      if (blockHash.startsWith('0000')) {
        break;
      }
      nonce++;
    }

    const block = this.blockRepo.create({
      agentId: dto.agentId,
      userId,
      blockHeight: currentHeight,
      blockType: dto.blockType,
      dataHash,
      dataSummary: dto.dataSummary || '',
      previousHash,
      blockHash,
      nonce,
      maturitySnapshot: 0, // 后面由调用方更新
    });

    const saved = await this.blockRepo.save(block);
    this.logger.verbose(
      `存证区块 #${currentHeight} 已添加，类型: ${dto.blockType}，哈希: ${blockHash.slice(0, 16)}...`,
    );
    return saved;
  }

  /**
   * 获取最新区块
   */
  async getLatestBlock(agentId: string, userId: string): Promise<AttestationBlockEntity | null> {
    return this.blockRepo.findOne({
      where: { agentId, userId },
      order: { blockHeight: 'DESC' },
    });
  }

  /**
   * 获取指定范围内的区块
   */
  async getBlocks(
    agentId: string,
    userId: string,
    options: { fromHeight?: number; toHeight?: number; limit?: number; offset?: number } = {},
  ): Promise<AttestationBlockEntity[]> {
    const qb = this.blockRepo
      .createQueryBuilder('block')
      .where('block.agentId = :agentId', { agentId })
      .andWhere('block.userId = :userId', { userId });

    if (options.fromHeight !== undefined) {
      qb.andWhere('block.blockHeight >= :fromHeight', { fromHeight: options.fromHeight });
    }
    if (options.toHeight !== undefined) {
      qb.andWhere('block.blockHeight <= :toHeight', { toHeight: options.toHeight });
    }

    qb.orderBy('block.blockHeight', 'DESC');

    if (options.limit) {
      qb.take(options.limit);
    }
    if (options.offset) {
      qb.skip(options.offset);
    }

    return qb.getMany();
  }

  /**
   * 获取链长
   */
  async getChainHeight(agentId: string, userId: string): Promise<number> {
    const latest = await this.getLatestBlock(agentId, userId);
    return latest ? latest.blockHeight + 1 : 0;
  }

  /**
   * 验证整条链的完整性
   */
  async verifyChain(agentId: string, userId: string): Promise<ChainVerificationResult> {
    const blocks = await this.getBlocks(agentId, userId, { limit: 1000 });
    
    if (blocks.length === 0) {
      return {
        isValid: false,
        blockCount: 0,
        message: '链不存在',
      };
    }

    // 按高度排序
    blocks.sort((a, b) => a.blockHeight - b.blockHeight);

    // 验证创世区块
    const genesis = blocks[0];
    if (genesis.blockHeight !== 0 || genesis.previousHash !== '0'.repeat(64)) {
      return {
        isValid: false,
        blockCount: blocks.length,
        brokenAt: 0,
        message: '创世区块无效',
      };
    }

    // 验证每个区块
    for (let i = 1; i < blocks.length; i++) {
      const current = blocks[i];
      const previous = blocks[i - 1];

      // 检查前哈希指向
      if (current.previousHash !== previous.blockHash) {
        return {
          isValid: false,
          blockCount: blocks.length,
          brokenAt: current.blockHeight,
          message: `区块 #${current.blockHeight} 的前哈希不匹配`,
        };
      }

      // 验证区块哈希（简化验证，不重新计算nonce）
      const blockData = `${current.blockHeight}:${new Date(current.createdAt).getTime()}:${current.agentId}:${current.dataHash}:${current.previousHash}:${current.nonce}`;
      const computedHash = this.sha256(blockData);
      
      if (computedHash !== current.blockHash) {
        return {
          isValid: false,
          blockCount: blocks.length,
          brokenAt: current.blockHeight,
          message: `区块 #${current.blockHeight} 的哈希验证失败，数据可能被篡改`,
        };
      }
    }

    return {
      isValid: true,
      blockCount: blocks.length,
      message: `存证链完整，共 ${blocks.length} 个区块，数据可信`,
    };
  }

  /**
   * 更新区块的成熟度快照
   * 在进化后调用
   */
  async updateMaturitySnapshot(
    blockId: string,
    userId: string,
    maturity: number,
  ): Promise<void> {
    await this.blockRepo.update({ id: blockId, userId }, { maturitySnapshot: maturity });
  }

  /**
   * 生成存在性证明
   * 返回一段可以证明Agent在某个时间点存在的文本
   */
  async generateExistenceProof(agentId: string, userId: string): Promise<string> {
    const chainHeight = await this.getChainHeight(agentId, userId);
    const latestBlock = await this.getLatestBlock(agentId, userId);

    if (!latestBlock || chainHeight === 0) {
      return '该Agent暂无存证记录';
    }

    const verification = await this.verifyChain(agentId, userId);

    return `
【智能体存在性证明】
Agent ID: ${agentId}
存证链高度: ${chainHeight} 个区块
创世时间: ${await this.getGenesisTime(agentId, userId)}
最新存证时间: ${latestBlock.createdAt.toISOString()}
最新区块哈希: ${latestBlock.blockHash}
链完整性: ${verification.isValid ? '✅ 完整可信' : '❌ 已被篡改'}

—— 元界永生引擎 出具
    `.trim();
  }

  /**
   * 获取创世时间
   */
  private async getGenesisTime(agentId: string, userId: string): Promise<string> {
    const genesis = await this.blockRepo.findOne({
      where: { agentId, userId, blockHeight: 0 },
    });
    return genesis ? genesis.createdAt.toISOString() : '未知';
  }

  /**
   * SHA-256 哈希
   */
  private sha256(data: string): string {
    return createHash('sha256').update(data).digest('hex');
  }
}
