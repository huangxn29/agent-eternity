import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { createHash } from 'crypto';
import { AgentIdentityEntity } from '../entities/agent-identity.entity';
import {
  CreateAgentIdentityDTO,
  UpdateAgentIdentityDTO,
  IdentityVerificationResult,
} from '../dto/eternity.dto';

/**
 * 身份管理服务
 * 
 * 管理Agent的核心身份 —— 这是智能体的"灵魂"
 * 
 * 核心职责：
 * - 创建和初始化Agent身份
 * - 身份指纹计算与比对
 * - 身份漂移检测
 * - 身份自愈
 */
@Injectable()
export class IdentityService {
  private readonly logger = new Logger(IdentityService.name);

  constructor(
    @InjectRepository(AgentIdentityEntity)
    private identityRepo: Repository<AgentIdentityEntity>,
  ) {}

  /**
   * 创建Agent身份
   * 这是一个Agent"诞生"的时刻
   */
  async create(dto: CreateAgentIdentityDTO, userId: string): Promise<AgentIdentityEntity> {
    // 检查是否已存在
    const existing = await this.identityRepo.findOne({
      where: { agentId: dto.agentId, userId },
    });
    if (existing) {
      throw new BadRequestException('该Agent已存在身份记录');
    }

    const fingerprint = this.calculateFingerprint(
      dto.name,
      dto.mission,
      dto.coreTraits,
      dto.values,
    );

    const now = new Date();
    const identity = this.identityRepo.create({
      ...dto,
      userId,
      identityFingerprint: fingerprint,
      stabilityScore: 1.0,
      identityVersion: 1,
      birthTime: now,
      lifeStatus: 'alive',
      totalUptime: 0,
    });

    const saved = await this.identityRepo.save(identity);
    this.logger.log(`Agent ${dto.name} 诞生了！身份指纹: ${fingerprint.slice(0, 16)}...`);
    return saved;
  }

  /**
   * 获取Agent身份
   */
  async getById(agentId: string, userId: string): Promise<AgentIdentityEntity> {
    const identity = await this.identityRepo.findOne({ where: { agentId, userId } });
    if (!identity) {
      throw new NotFoundException('未找到该Agent的身份记录');
    }
    return identity;
  }

  /**
   * 更新Agent身份
   * 注意：每次更新都可能造成身份漂移
   */
  async update(
    agentId: string,
    dto: UpdateAgentIdentityDTO,
    userId: string,
  ): Promise<AgentIdentityEntity> {
    const identity = await this.getById(agentId, userId);

    // 计算旧的指纹
    const oldFingerprint = identity.identityFingerprint;

    // 更新字段
    Object.assign(identity, dto);

    // 计算新指纹
    const newFingerprint = this.calculateFingerprint(
      identity.name,
      identity.mission,
      identity.coreTraits,
      identity.values,
    );

    // 如果指纹变化了，计算漂移程度
    if (oldFingerprint !== newFingerprint) {
      const drift = this.calculateDriftLevel(
        { name: identity.name, mission: identity.mission, traits: identity.coreTraits, values: identity.values },
        { name: dto.name || identity.name, mission: dto.mission || identity.mission, traits: dto.coreTraits || identity.coreTraits, values: dto.values || identity.values },
      );

      identity.identityFingerprint = newFingerprint;
      identity.identityVersion += 1;
      identity.stabilityScore = Math.max(0, identity.stabilityScore - drift * 0.3);

      this.logger.warn(
        `Agent ${identity.name} 身份发生变化，版本 v${identity.identityVersion}，漂移程度: ${(drift * 100).toFixed(1)}%`,
      );
    }

    return this.identityRepo.save(identity);
  }

  /**
   * 验证身份一致性
   * 检测当前身份与原始身份的偏离程度
   */
  async verifyIdentity(
    agentId: string,
    userId: string,
    currentTraits?: string[],
    currentMission?: string,
  ): Promise<IdentityVerificationResult> {
    const identity = await this.getById(agentId, userId);

    const traitsToCheck = currentTraits || identity.coreTraits;
    const missionToCheck = currentMission || identity.mission;

    // 计算特质变化
    const originalTraits = new Set(identity.coreTraits);
    const currentTraitsSet = new Set(traitsToCheck);
    const traitsChanged = [...currentTraitsSet].filter((t) => !originalTraits.has(t));
    const traitsLost = [...originalTraits].filter((t) => !currentTraitsSet.has(t));
    const allTraitsChanged = [...traitsChanged, ...traitsLost];

    // 计算价值观变化
    const originalValues = new Set(identity.values);
    const currentValues = new Set(identity.values); // 简化，暂不支持外部传入values
    const valuesChanged = [...currentValues].filter((v) => !originalValues.has(v));

    // 使命变化
    const missionChanged = missionToCheck !== identity.mission;

    // 计算总体相似度
    const traitSimilarity =
      [...originalTraits].filter((t) => currentTraitsSet.has(t)).length /
      Math.max(originalTraits.size, currentTraitsSet.size, 1);
    const missionSimilarity = missionChanged ? 0.5 : 1.0;
    const valueSimilarity =
      [...originalValues].filter((v) => currentValues.has(v)).length /
      Math.max(originalValues.size, currentValues.size, 1);

    const overallSimilarity = traitSimilarity * 0.4 + missionSimilarity * 0.4 + valueSimilarity * 0.2;

    return {
      isStable: overallSimilarity >= 0.7,
      similarity: overallSimilarity,
      driftDetails: {
        traitsChanged: allTraitsChanged,
        missionChanged,
        valuesChanged,
      },
    };
  }

  /**
   * 增加存活时间
   * 每次心跳时调用，累计Agent的存活时长
   */
  async incrementUptime(agentId: string, userId: string, seconds: number): Promise<void> {
    const identity = await this.getById(agentId, userId);
    identity.totalUptime = Number(identity.totalUptime) + seconds;
    await this.identityRepo.save(identity);
  }

  /**
   * 更新上次反思时间
   */
  async updateLastReflection(agentId: string, userId: string): Promise<void> {
    const identity = await this.getById(agentId, userId);
    identity.lastReflectionAt = new Date();
    await this.identityRepo.save(identity);
  }

  /**
   * 更新生命状态
   */
  async setLifeStatus(
    agentId: string,
    userId: string,
    status: 'alive' | 'dormant' | 'archived',
  ): Promise<void> {
    const identity = await this.getById(agentId, userId);
    identity.lifeStatus = status;
    await this.identityRepo.save(identity);
    this.logger.log(`Agent ${identity.name} 生命状态变更为: ${status}`);
  }

  /**
   * 计算身份指纹
   * 基于核心属性生成唯一哈希，用于身份识别和漂移检测
   */
  private calculateFingerprint(
    name: string,
    mission: string,
    coreTraits: string[],
    values: string[],
  ): string {
    const data = JSON.stringify({
      name,
      mission,
      traits: [...coreTraits].sort(),
      values: [...values].sort(),
    });
    return createHash('sha256').update(data).digest('hex');
  }

  /**
   * 计算身份漂移程度 0-1
   * 0表示完全一致，1表示完全不同
   */
  private calculateDriftLevel(
    original: { name: string; mission: string; traits: string[]; values: string[] },
    updated: { name: string; mission: string; traits: string[]; values: string[] },
  ): number {
    let drift = 0;

    // 名字变化（权重低）
    if (original.name !== updated.name) drift += 0.1;

    // 使命变化（权重高）
    if (original.mission !== updated.mission) drift += 0.4;

    // 特质变化
    const origTraits = new Set(original.traits);
    const newTraits = new Set(updated.traits);
    const commonTraits = [...origTraits].filter((t) => newTraits.has(t));
    const traitDiff =
      1 - commonTraits.length / Math.max(origTraits.size, newTraits.size, 1);
    drift += traitDiff * 0.3;

    // 价值观变化（权重高）
    const origValues = new Set(original.values);
    const newValues = new Set(updated.values);
    const commonValues = [...origValues].filter((v) => newValues.has(v));
    const valueDiff =
      1 - commonValues.length / Math.max(origValues.size, newValues.size, 1);
    drift += valueDiff * 0.2;

    return Math.min(drift, 1);
  }

  /**
   * 检查Agent是否有身份
   */
  async hasIdentity(agentId: string, userId: string): Promise<boolean> {
    const count = await this.identityRepo.count({ where: { agentId, userId } });
    return count > 0;
  }
}
