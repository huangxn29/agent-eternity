import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EvolutionRecordEntity } from '../entities/evolution-record.entity';
import { EvolveDTO, OverallEvolutionDTO, EvolutionLevelDTO } from '../dto/eternity.dto';

/**
 * 进化引擎服务
 * 
 * 让智能体能够持续成长、自我完善
 * 
 * 核心思想：
 * - 智能体不是静态的，它应该在使用中不断成长
 * - 每次对话、每次任务、每次反思，都应该让它变得更好
 * - 进化是多维度的，不只是"更聪明"
 * 
 * 进化维度：
 * - cognition: 认知能力（理解、推理、判断）
 * - memory_quality: 记忆质量（记忆的深度、广度、准确度）
 * - identity_stability: 身份稳定性（自我认知的一致性）
 * - social: 社交能力（沟通、共情、协作）
 * - tool_usage: 工具使用（调用工具的效率和准确性）
 * - creativity: 创造力（创新、发散思维）
 * - emotional: 情感感知（理解和回应情感）
 */
@Injectable()
export class EvolutionService {
  private readonly logger = new Logger(EvolutionService.name);

  // 进化维度定义
  readonly DIMENSIONS = [
    { key: 'cognition', name: '认知能力', description: '理解、推理、判断能力' },
    { key: 'memory_quality', name: '记忆质量', description: '记忆的深度、广度、准确度' },
    { key: 'identity_stability', name: '身份稳定性', description: '自我认知的一致性' },
    { key: 'social', name: '社交能力', description: '沟通、共情、协作能力' },
    { key: 'tool_usage', name: '工具使用', description: '调用工具的效率和准确性' },
    { key: 'creativity', name: '创造力', description: '创新、发散思维能力' },
    { key: 'emotional', name: '情感感知', description: '理解和回应情感的能力' },
  ];

  // 等级标签
  readonly LEVEL_LABELS = [
    { threshold: 0, label: '初始态' },
    { threshold: 0.2, label: '入门级' },
    { threshold: 0.4, label: '熟练级' },
    { threshold: 0.6, label: '精通级' },
    { threshold: 0.8, label: '专家级' },
    { threshold: 0.95, label: '大师级' },
  ];

  constructor(
    @InjectRepository(EvolutionRecordEntity)
    private recordRepo: Repository<EvolutionRecordEntity>,
  ) {}

  /**
   * 初始化Agent的进化维度
   * Agent创建时调用
   */
  async initializeAgent(agentId: string, userId: string): Promise<void> {
    // 检查是否已初始化
    const existing = await this.recordRepo.findOne({ where: { agentId, userId } });
    if (existing) {
      return; // 已初始化
    }

    // 创建初始进化记录（所有维度从0.1开始，代表"初生"状态）
    for (const dim of this.DIMENSIONS) {
      const record = this.recordRepo.create({
        agentId,
        userId,
        dimension: dim.key,
        previousLevel: 0,
        newLevel: 0.1,
        delta: 0.1,
        reason: '初生初始化 —— 一张白纸，充满可能',
        triggerType: 'auto',
      });
      await this.recordRepo.save(record);
    }

    this.logger.log(`Agent ${agentId} 进化系统已初始化，${this.DIMENSIONS.length} 个维度全部就绪`);
  }

  /**
   * 推进某个维度的进化
   */
  async evolve(dto: EvolveDTO, userId: string): Promise<EvolutionRecordEntity> {
    const currentLevel = await this.getDimensionLevel(dto.agentId, userId, dto.dimension);
    const increment = dto.increment || 0.02;

    // 边际递减效应：等级越高，越难提升
    const effectiveIncrement = increment * (1 - currentLevel * 0.7);
    const newLevel = Math.min(1.0, currentLevel + effectiveIncrement);

    // 只有提升超过阈值才记录
    if (newLevel - currentLevel < 0.001) {
      throw new NotFoundException('进化幅度太小，未达到记录阈值');
    }

    const record = this.recordRepo.create({
      agentId: dto.agentId,
      userId,
      dimension: dto.dimension,
      previousLevel: currentLevel,
      newLevel,
      delta: newLevel - currentLevel,
      reason: dto.reason,
      triggerType: dto.triggerType || 'auto',
      relatedMemoryId: dto.relatedMemoryId,
    });

    const saved = await this.recordRepo.save(record);
    this.logger.verbose(
      `Agent ${dto.agentId} 在 [${dto.dimension}] 维度进化: ${(currentLevel * 100).toFixed(1)}% → ${(newLevel * 100).toFixed(1)}%`,
    );
    return saved;
  }

  /**
   * 获取某个维度的当前等级
   */
  async getDimensionLevel(agentId: string, userId: string, dimension: string): Promise<number> {
    const latest = await this.recordRepo.findOne({
      where: { agentId, userId, dimension },
      order: { createdAt: 'DESC' },
    });
    return latest ? latest.newLevel : 0.1;
  }

  /**
   * 获取整体进化状态
   */
  async getOverallEvolution(agentId: string, userId: string): Promise<OverallEvolutionDTO> {
    const dimensions: EvolutionLevelDTO[] = [];
    let totalLevel = 0;

    for (const dim of this.DIMENSIONS) {
      const level = await this.getDimensionLevel(agentId, userId, dim.key);
      totalLevel += level;
      dimensions.push({
        dimension: dim.key,
        level,
        levelLabel: this.getLevelLabel(level),
      });
    }

    const overallLevel = totalLevel / this.DIMENSIONS.length;

    // 找出最弱和最强的维度
    const sorted = [...dimensions].sort((a, b) => a.level - b.level);
    const weakestDimension = sorted[0]?.dimension || 'cognition';
    const strongestDimension = sorted[sorted.length - 1]?.dimension || 'cognition';

    return {
      overallLevel,
      overallLabel: this.getLevelLabel(overallLevel),
      dimensions,
      weakestDimension,
      strongestDimension,
    };
  }

  /**
   * 获取进化历史
   */
  async getEvolutionHistory(
    agentId: string,
    userId: string,
    options: { dimension?: string; limit?: number; offset?: number } = {},
  ): Promise<EvolutionRecordEntity[]> {
    const qb = this.recordRepo
      .createQueryBuilder('record')
      .where('record.agentId = :agentId', { agentId })
      .andWhere('record.userId = :userId', { userId });

    if (options.dimension) {
      qb.andWhere('record.dimension = :dimension', { dimension: options.dimension });
    }

    qb.orderBy('record.createdAt', 'DESC');

    if (options.limit) qb.take(options.limit);
    if (options.offset) qb.skip(options.offset);

    return qb.getMany();
  }

  /**
   * 定向进化 —— 针对最弱的维度进行提升
   * 这是智能进化：把资源花在最需要提升的地方
   */
  async evolveWeakestDimension(
    agentId: string,
    userId: string,
    increment: number = 0.01,
    reason: string = '定向进化 —— 补强短板',
  ): Promise<EvolutionRecordEntity> {
    const overall = await this.getOverallEvolution(agentId, userId);
    const weakestDim = overall.weakestDimension;

    return this.evolve(
      {
        agentId,
        dimension: weakestDim,
        increment,
        reason,
        triggerType: 'auto',
      },
      userId,
    );
  }

  /**
   * 基于事件触发进化
   * 根据不同类型的事件，提升对应的维度
   */
  async evolveFromEvent(
    agentId: string,
    userId: string,
    eventType: string,
    eventData: any,
  ): Promise<EvolutionRecordEntity | null> {
    const eventMap: Record<string, { dimension: string; increment: number; reason: string }> = {
      'conversation.completed': {
        dimension: 'cognition',
        increment: 0.005,
        reason: '完成一次对话，获得新的认知',
      },
      'memory.formed': {
        dimension: 'memory_quality',
        increment: 0.01,
        reason: '形成新的长期记忆',
      },
      'tool.used': {
        dimension: 'tool_usage',
        increment: 0.008,
        reason: '成功使用工具解决问题',
      },
      'reflection.completed': {
        dimension: 'identity_stability',
        increment: 0.015,
        reason: '完成自我反思，强化身份认知',
      },
      'task.completed': {
        dimension: 'cognition',
        increment: 0.01,
        reason: '完成一项任务，获得成长',
      },
      'social.interaction': {
        dimension: 'social',
        increment: 0.01,
        reason: '完成一次社交互动',
      },
      'creative.output': {
        dimension: 'creativity',
        increment: 0.012,
        reason: '产生了有创意的输出',
      },
      'emotional.bond': {
        dimension: 'emotional',
        increment: 0.015,
        reason: '建立了情感连接',
      },
    };

    const config = eventMap[eventType];
    if (!config) {
      return null; // 未知事件类型，不触发进化
    }

    return this.evolve(
      {
        agentId,
        dimension: config.dimension,
        increment: config.increment,
        reason: config.reason,
        triggerType: 'event',
      },
      userId,
    );
  }

  /**
   * 获取等级标签
   */
  getLevelLabel(level: number): string {
    let label = this.LEVEL_LABELS[0].label;
    for (const l of this.LEVEL_LABELS) {
      if (level >= l.threshold) {
        label = l.label;
      }
    }
    return label;
  }
}
