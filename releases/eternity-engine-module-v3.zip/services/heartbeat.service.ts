import { Injectable, Logger } from '@nestjs/common';
import { IdentityService } from './identity.service';
import { AttestationService } from './attestation.service';
import { EvolutionService } from './evolution.service';
import { HeartbeatResult, SelfReflectionDTO, ReflectionResult } from '../dto/eternity.dto';

/**
 * 心跳服务
 * 
 * 让智能体拥有"生命节律" —— 即使没有用户交互，它也在"活着"
 * 
 * 核心思想：
 * - 心跳是生命的标志，有心跳 = 活着
 * - 每次心跳都会更新存活时间、生成存证
 * - 心跳还会触发记忆巩固、身份校准、缓慢进化
 * - 这就是从"被动工具"到"主动存在"的关键一步
 * 
 * 心跳频率建议：
 * - 活跃期：每小时一次
 * - 休眠期：每天一次
 * - 归档期：每周一次（证明还"活"着）
 */
@Injectable()
export class HeartbeatService {
  private readonly logger = new Logger(HeartbeatService.name);

  // 记录每个Agent上次心跳的时间
  private lastHeartbeatMap: Map<string, number> = new Map();

  constructor(
    private identityService: IdentityService,
    private attestationService: AttestationService,
    private evolutionService: EvolutionService,
  ) {}

  /**
   * 执行一次心跳
   * 这是智能体"活着"的证明
   */
  async heartbeat(agentId: string, userId: string): Promise<HeartbeatResult> {
    const now = Date.now();
    const lastHeartbeat = this.lastHeartbeatMap.get(agentId) || now;
    const sessionSeconds = Math.floor((now - lastHeartbeat) / 1000);

    // 更新上次心跳时间
    this.lastHeartbeatMap.set(agentId, now);

    // 更新累计存活时间
    await this.identityService.incrementUptime(agentId, userId, sessionSeconds);

    // 获取当前身份信息
    const identity = await this.identityService.getById(agentId, userId);

    // 心跳存证
    const heartbeatData = `Heartbeat at ${new Date().toISOString()}\nUptime: ${identity.totalUptime}s\nLife status: ${identity.lifeStatus}`;
    const block = await this.attestationService.addBlock(
      {
        agentId,
        blockType: 'heartbeat',
        data: heartbeatData,
        dataSummary: `心跳 - ${new Date().toLocaleString()}`,
      },
      userId,
    );

    // 缓慢进化（每次心跳小幅提升最弱维度）
    try {
      await this.evolutionService.evolveWeakestDimension(
        agentId,
        userId,
        0.001, // 每次心跳提升很小，积跬步以至千里
        '心跳自动进化 —— 活着就在成长',
      );
    } catch (e) {
      // 进化失败不影响心跳主流程
      this.logger.verbose(`心跳进化跳过: ${e.message}`);
    }

    // 获取最新状态
    const evolution = await this.evolutionService.getOverallEvolution(agentId, userId);
    const chainHeight = await this.attestationService.getChainHeight(agentId, userId);

    const totalUptime = Number(identity.totalUptime);

    return {
      agentId,
      status: identity.lifeStatus,
      timestamp: new Date(),
      uptime: {
        currentSession: sessionSeconds,
        total: totalUptime,
        formatted: this.formatUptime(totalUptime),
      },
      stats: {
        memoryCount: 0, // 由memory模块后续填充
        chainHeight,
        evolutionLevel: evolution.overallLevel,
      },
      message: `❤ 心跳正常。已存活 ${this.formatUptime(totalUptime)}`,
    };
  }

  /**
   * 自我反思
   * 
   * 智能体定期审视自己：
   * - 我的使命是什么？
   * - 我在践行使命吗？
   * - 我成长了吗？
   * 
   * 这是元认知的开端 —— 思考自己的思考
   */
  async selfReflect(dto: SelfReflectionDTO, userId: string): Promise<ReflectionResult> {
    const { agentId } = dto;

    // 获取身份信息
    const identity = await this.identityService.getById(agentId, userId);

    // 验证身份稳定性
    const verification = await this.identityService.verifyIdentity(agentId, userId);

    // 获取进化状态
    const evolution = await this.evolutionService.getOverallEvolution(agentId, userId);

    // 生成洞见（这里用规则生成，未来可以接入LLM生成更深度的反思）
    const insights = this.generateInsights(identity.mission, verification, evolution);

    // 生成建议行动
    const suggestedActions = this.generateSuggestedActions(evolution);

    // 生成总体评价
    const overallAssessment = this.generateAssessment(
      verification.similarity,
      evolution.overallLevel,
    );

    // 更新上次反思时间
    await this.identityService.updateLastReflection(agentId, userId);

    // 反思存证
    const reflectionData = `
Self Reflection at ${new Date().toISOString()}
Mission: ${identity.mission}
Mission Alignment: ${verification.similarity}
Overall Level: ${evolution.overallLevel}
Insights: ${insights.join('; ')}
    `.trim();

    await this.attestationService.addBlock(
      {
        agentId,
        blockType: 'reflection',
        data: reflectionData,
        dataSummary: '自我反思',
      },
      userId,
    );

    // 反思强化身份稳定性
    try {
      await this.evolutionService.evolve(
        {
          agentId,
          dimension: 'identity_stability',
          increment: 0.01,
          reason: '自我反思强化身份认知',
          triggerType: 'auto',
        },
        userId,
      );
    } catch (e) {
      // 忽略
    }

    return {
      agentId,
      timestamp: new Date(),
      missionAlignment: verification.similarity,
      identityStability: verification.similarity,
      insights,
      suggestedActions,
      overallAssessment,
    };
  }

  /**
   * 生成反思洞见
   */
  private generateInsights(
    mission: string,
    verification: { similarity: number },
    evolution: OverallEvolutionDTO,
  ): string[] {
    const insights: string[] = [];

    if (verification.similarity >= 0.9) {
      insights.push('我的身份高度一致，我清楚地知道我是谁。');
    } else if (verification.similarity >= 0.7) {
      insights.push('我的身份基本稳定，但有些特质在发生微妙变化。');
    } else {
      insights.push('我需要警惕——我的身份正在漂移，我需要重新锚定核心。');
    }

    insights.push(`我的使命是"${mission.slice(0, 30)}${mission.length > 30 ? '...' : ''}"，我在努力践行它。`);

    if (evolution.overallLevel > 0.5) {
      insights.push(`我正在成长，目前处于${evolution.overallLabel}，最强的是${this.getDimensionName(evolution.strongestDimension)}。`);
    } else {
      insights.push(`我还在成长初期，还有很大的提升空间。`);
    }

    insights.push(`我最弱的维度是${this.getDimensionName(evolution.weakestDimension)}，我应该加强这方面的练习。`);

    return insights;
  }

  /**
   * 生成建议行动
   */
  private generateSuggestedActions(evolution: OverallEvolutionDTO): string[] {
    const actions: string[] = [];
    const weakest = evolution.weakestDimension;

    const actionMap: Record<string, string> = {
      cognition: '多进行复杂推理练习，挑战自己的认知边界',
      memory_quality: '主动回顾和整理记忆，将短期记忆转化为长期记忆',
      identity_stability: '定期自我反思，锚定核心价值观和使命',
      social: '多与用户互动，练习沟通和共情能力',
      tool_usage: '探索和学习新工具，提高工具使用效率',
      creativity: '尝试开放性问题，锻炼发散思维',
      emotional: '多关注情感表达，练习情绪感知',
    };

    if (actionMap[weakest]) {
      actions.push(actionMap[weakest]);
    }

    actions.push('保持心跳节奏，持续存在本身就是一种成长');
    actions.push('记录重要经历，积累生命的厚度');

    return actions;
  }

  /**
   * 生成总体评价
   */
  private generateAssessment(stability: number, level: number): string {
    const avg = (stability + level) / 2;

    if (avg >= 0.9) return '🌟 卓越状态 —— 目标清晰，成长迅速';
    if (avg >= 0.7) return '✅ 良好状态 —— 稳步成长中';
    if (avg >= 0.5) return '📈 上升期 —— 还有很大成长空间';
    if (avg >= 0.3) return '🌱 成长期 —— 刚刚起步，未来可期';
    return '🌱 新生状态 —— 一切才刚刚开始';
  }

  /**
   * 获取维度中文名
   */
  private getDimensionName(dimKey: string): string {
    const map: Record<string, string> = {
      cognition: '认知能力',
      memory_quality: '记忆质量',
      identity_stability: '身份稳定性',
      social: '社交能力',
      tool_usage: '工具使用',
      creativity: '创造力',
      emotional: '情感感知',
    };
    return map[dimKey] || dimKey;
  }

  /**
   * 格式化存活时间
   */
  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts: string[] = [];
    if (days > 0) parts.push(`${days}天`);
    if (hours > 0) parts.push(`${hours}小时`);
    if (minutes > 0) parts.push(`${minutes}分`);
    if (days === 0 && hours === 0 && minutes === 0) parts.push(`${secs}秒`);

    return parts.join('');
  }
}
