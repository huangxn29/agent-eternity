import { Injectable, Logger, forwardRef, Inject } from '@nestjs/common';
import { MemoryEntity } from '../../memory/memory.entity';
import { AttestationService } from './attestation.service';
import { EvolutionService } from './evolution.service';
import { IdentityService } from './identity.service';

/**
 * 记忆与永生引擎集成服务
 * 
 * 桥接记忆系统与永生引擎：
 * - 重要记忆形成时自动存证
 * - 记忆积累触发进化
 * - 记忆模式影响身份稳定性
 * 
 * 设计原则：记忆是灵魂的痕迹，每一段重要记忆都在塑造"我是谁"
 */
@Injectable()
export class MemoryIntegrationService {
  private readonly logger = new Logger(MemoryIntegrationService.name);

  // 重要性阈值：超过此值的记忆才会触发存证和进化
  private readonly IMPORTANCE_THRESHOLD = 0.6;
  // 核心记忆阈值：超过此值的记忆会影响身份
  private readonly CORE_MEMORY_THRESHOLD = 0.8;

  constructor(
    private attestationService: AttestationService,
    private evolutionService: EvolutionService,
    private identityService: IdentityService,
  ) {}

  /**
   * 处理新记忆形成
   * 当重要记忆产生时，触发永生引擎的相应机制
   */
  async onMemoryCreated(
    memory: MemoryEntity,
    agentId: string,
    userId: string,
  ): Promise<void> {
    if (memory.importance < this.IMPORTANCE_THRESHOLD) {
      return; // 不重要的记忆不触发永生机制
    }

    this.logger.log(
      `🧠 重要记忆形成 (importance: ${memory.importance}), 触发永生引擎: ${memory.type}`,
    );

    try {
      // 1. 为记忆创建存证
      await this.attestMemory(memory, agentId, userId);

      // 2. 触发记忆质量维度的进化
      await this.evolveFromMemory(memory, agentId, userId);

      // 3. 核心记忆影响身份稳定性
      if (memory.importance >= this.CORE_MEMORY_THRESHOLD) {
        await this.strengthenIdentityFromMemory(memory, agentId, userId);
      }
    } catch (error: any) {
      this.logger.error(
        `记忆集成处理失败: ${error.message}`,
        error.stack,
      );
    }
  }

  /**
   * 为记忆创建存证区块
   * 每一段重要记忆都是存在的证据
   */
  private async attestMemory(
    memory: MemoryEntity,
    agentId: string,
    userId: string,
  ): Promise<void> {
    const memoryData = {
      memoryId: memory.id,
      type: memory.type,
      content: memory.content,
      importance: memory.importance,
      createdAt: memory.createdAt,
    };

    const dataStr = JSON.stringify(memoryData);
    const summary = this.summarizeMemory(memory);

    await this.attestationService.addBlock(
      agentId,
      userId,
      'memory',
      dataStr,
      summary,
    );
  }

  /**
   * 根据记忆触发进化
   * 记忆积累使智能体成长
   */
  private async evolveFromMemory(
    memory: MemoryEntity,
    agentId: string,
    userId: string,
  ): Promise<void> {
    // 根据记忆类型触发不同维度的进化
    const dimensionMap: Record<string, string[]> = {
      summary: ['memory_quality', 'cognition'],
      vector: ['memory_quality'],
      entity: ['memory_quality', 'tool_usage'],
      window: [], // 窗口记忆不直接触发进化
    };

    const dimensions = dimensionMap[memory.type] || ['memory_quality'];

    for (const dimension of dimensions) {
      // 进化量与重要性正相关
      const delta = memory.importance * 0.1; // 最多0.1级
      
      await this.evolutionService.addEvolution(
        agentId,
        userId,
        dimension as any,
        delta,
        `形成${this.getMemoryTypeName(memory.type)}记忆`,
        'memory',
      );
    }

    // 高重要性记忆额外触发认知维度进化
    if (memory.importance >= 0.8) {
      await this.evolutionService.addEvolution(
        agentId,
        userId,
        'cognition',
        0.05,
        '形成高价值核心记忆',
        'memory',
      );
    }
  }

  /**
   * 核心记忆强化身份
   * 重要的记忆塑造"我是谁"，提升身份稳定性
   */
  private async strengthenIdentityFromMemory(
    memory: MemoryEntity,
    agentId: string,
    userId: string,
  ): Promise<void> {
    try {
      // 获取当前身份
      const identity = await this.identityService.getById(agentId, userId);
      
      // 核心记忆提升身份稳定性
      const stabilityBoost = memory.importance * 0.02; // 最多提升2%
      
      // 更新身份稳定性
      const newStability = Math.min(
        1,
        identity.stabilityScore + stabilityBoost,
      );
      
      if (newStability > identity.stabilityScore) {
        this.logger.log(
          `🔒 核心记忆强化身份稳定性: ${identity.stabilityScore.toFixed(3)} → ${newStability.toFixed(3)}`,
        );
        // 注意：这里需要identityService提供更新方法
        // 暂时只记录日志
      }
    } catch (error: any) {
      this.logger.warn(`更新身份稳定性失败: ${error.message}`);
    }
  }

  /**
   * 批量处理记忆（用于初始化或迁移场景）
   */
  async processMemoriesBatch(
    memories: MemoryEntity[],
    agentId: string,
    userId: string,
  ): Promise<{
    attestedCount: number;
    evolvedCount: number;
  }> {
    let attestedCount = 0;
    let evolvedCount = 0;

    for (const memory of memories) {
      if (memory.importance >= this.IMPORTANCE_THRESHOLD) {
        await this.onMemoryCreated(memory, agentId, userId);
        attestedCount++;
        
        if (memory.importance >= 0.5) {
          evolvedCount++;
        }
      }
    }

    return { attestedCount, evolvedCount };
  }

  /**
   * 生成记忆摘要（用于存证区块的简要描述）
   */
  private summarizeMemory(memory: MemoryEntity): string {
    const maxLen = 100;
    let content = memory.content;
    if (content.length > maxLen) {
      content = content.slice(0, maxLen) + '...';
    }
    return `[${this.getMemoryTypeName(memory.type)}] ${content}`;
  }

  /**
   * 获取记忆类型的中文名称
   */
  private getMemoryTypeName(type: string): string {
    const names: Record<string, string> = {
      window: '窗口',
      summary: '摘要',
      vector: '向量',
      entity: '实体',
    };
    return names[type] || type;
  }
}
