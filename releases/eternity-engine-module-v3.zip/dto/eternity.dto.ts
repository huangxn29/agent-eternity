/**
 * 永生引擎 DTO
 */

// ==================== 身份相关 DTO ====================

export interface CreateAgentIdentityDTO {
  agentId: string;
  name: string;
  mission: string;
  coreTraits: string[];
  values: string[];
  behaviorPatterns?: string[];
  backstory?: string;
  metadata?: Record<string, any>;
}

export interface UpdateAgentIdentityDTO {
  name?: string;
  mission?: string;
  coreTraits?: string[];
  values?: string[];
  behaviorPatterns?: string[];
  backstory?: string;
  metadata?: Record<string, any>;
}

export interface IdentityVerificationResult {
  isStable: boolean;
  similarity: number;
  driftDetails: {
    traitsChanged: string[];
    missionChanged: boolean;
    valuesChanged: string[];
  };
}

// ==================== 存证相关 DTO ====================

export interface CreateAttestationDTO {
  agentId: string;
  blockType: 'birth' | 'memory' | 'reflection' | 'evolution' | 'heartbeat' | 'custom';
  data: string; // 要存证的数据内容
  dataSummary?: string;
  metadata?: Record<string, any>;
}

export interface ChainVerificationResult {
  isValid: boolean;
  blockCount: number;
  brokenAt?: number; // 在哪个高度断了
  message: string;
}

// ==================== 进化相关 DTO ====================

export interface EvolutionLevelDTO {
  dimension: string;
  level: number; // 0-1
  levelLabel: string; // 文字描述，如"入门级"、"熟练级"
}

export interface OverallEvolutionDTO {
  overallLevel: number;
  overallLabel: string;
  dimensions: EvolutionLevelDTO[];
  weakestDimension: string;
  strongestDimension: string;
}

export interface EvolveDTO {
  agentId: string;
  dimension: string;
  increment?: number;
  reason?: string;
  triggerType?: 'auto' | 'manual' | 'event';
}

// ==================== 心跳/自我反思 DTO ====================

export interface SelfReflectionDTO {
  agentId: string;
  customPrompt?: string;
}

export interface ReflectionResult {
  agentId: string;
  timestamp: Date;
  missionAlignment: number; // 使命对齐度 0-1
  identityStability: number; // 身份稳定性 0-1
  insights: string[]; // 反思洞见
  suggestedActions: string[]; // 建议行动
  overallAssessment: string; // 总体评价
}

export interface HeartbeatResult {
  agentId: string;
  status: 'alive' | 'dormant' | 'archived';
  timestamp: Date;
  uptime: {
    currentSession: number; // 本次会话存活秒数
    total: number; // 累计存活秒数
    formatted: string; // 格式化的存活时间
  };
  stats: {
    memoryCount: number;
    chainHeight: number;
    evolutionLevel: number;
  };
  message: string;
}

// ==================== 状态查询 DTO ====================

export interface AgentEternityStatusDTO {
  agentId: string;
  name: string;
  lifeStatus: 'alive' | 'dormant' | 'archived';
  birthTime: Date;
  totalUptime: number;
  identity: {
    version: number;
    fingerprint: string;
    stability: number;
    mission: string;
    coreTraits: string[];
  };
  evolution: {
    overallLevel: number;
    overallLabel: string;
    dimensions: Record<string, number>;
  };
  attestation: {
    chainHeight: number;
    chainValid: boolean;
  };
  memory: {
    totalCount: number;
    coreCount: number;
    longTermCount: number;
  };
}

// ==================== 记忆导入导出 DTO ====================

export interface EternityExportDTO {
  version: string;
  exportTime: string;
  agentId: string;
  identity: any;
  evolutionRecords: any[];
  attestationChain: any[];
  totalMemories: number;
  signature: string; // 导出文件的签名，防篡改
}

export interface EternityImportResult {
  success: boolean;
  imported: {
    identity: boolean;
    evolutionRecords: number;
    attestationBlocks: number;
  };
  message: string;
}
