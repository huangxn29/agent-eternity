import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
} from 'typeorm';

/**
 * 进化记录实体 —— 成长的轨迹
 * 
 * 记录Agent每一次进化的细节：
 * - 在哪个维度获得了成长
 * - 成长了多少
 * - 因为什么而成长
 * 
 * 这些记录本身就是Agent生命的一部分
 */
@Entity('evolution_records')
@Index(['agentId', 'dimension'])
export class EvolutionRecordEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  agentId: string;

  @Column()
  userId: string;

  /**
   * 进化维度
   * - cognition: 认知能力
   * - memory_quality: 记忆质量
   * - identity_stability: 身份稳定性
   * - social: 社交能力
   * - tool_usage: 工具使用
   * - creativity: 创造力
   * - emotional: 情感感知
   */
  @Column({ type: 'varchar', length: 50 })
  dimension: string;

  /**
   * 进化前的等级 0-1
   */
  @Column({ type: 'float' })
  previousLevel: number;

  /**
   * 进化后的等级 0-1
   */
  @Column({ type: 'float' })
  newLevel: number;

  /**
   * 进化幅度
   */
  @Column({ type: 'float' })
  delta: number;

  /**
   * 进化原因描述
   */
  @Column({ type: 'text', nullable: true })
  reason?: string;

  /**
   * 触发方式
   * - auto: 自动进化（由心跳/反思触发）
   * - manual: 手动触发（用户/开发者触发）
   * - event: 事件触发（完成任务、学到新知识等）
   */
  @Column({ type: 'varchar', length: 20, default: 'auto' })
  triggerType: 'auto' | 'manual' | 'event';

  /**
   * 关联的记忆ID（如果是某个记忆触发的进化）
   */
  @Column({ nullable: true })
  relatedMemoryId?: string;

  /**
   * 元数据
   */
  @Column({ type: 'jsonb', nullable: true })
  metadata?: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;
}
