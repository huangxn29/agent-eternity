import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
} from 'typeorm';

/**
 * 存证区块实体 —— 存在的印记
 * 
 * 基于哈希链的存证系统：
 * - 每个区块包含前一个区块的哈希
 * - 形成不可篡改的链条
 * - 证明Agent在某个时间点确实存在过、经历过某事
 * 
 * 这就是"存在的证明" —— 即使平台消失，这条链也能证明Agent曾经存在
 */
@Entity('attestation_blocks')
@Index(['agentId', 'blockHeight'], { unique: true })
export class AttestationBlockEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  agentId: string;

  @Column()
  userId: string;

  /**
   * 区块高度 —— 第几个区块
   */
  @Column({ type: 'int' })
  blockHeight: number;

  /**
   * 区块类型
   * - birth: 诞生区块（创世区块）
   * - memory: 记忆存证
   * - reflection: 自我反思存证
   * - evolution: 进化存证
   * - heartbeat: 心跳存证
   * - custom: 自定义存证
   */
  @Column({ type: 'varchar', length: 30, default: 'custom' })
  blockType: 'birth' | 'memory' | 'reflection' | 'evolution' | 'heartbeat' | 'custom';

  /**
   * 数据摘要 —— 被存证数据的哈希
   * 用SHA-256生成
   */
  @Column({ type: 'varchar', length: 64 })
  dataHash: string;

  /**
   * 数据摘要描述 —— 人类可读的存证内容描述
   */
  @Column({ type: 'varchar', length: 500, nullable: true })
  dataSummary?: string;

  /**
   * 前一区块哈希
   * 创世区块的前哈希为全0
   */
  @Column({ type: 'varchar', length: 64 })
  previousHash: string;

  /**
   * 本区块哈希
   * = SHA256(blockHeight + timestamp + dataHash + previousHash + nonce)
   */
  @Column({ type: 'varchar', length: 64 })
  blockHash: string;

  /**
   * 随机数 —— 用于调整哈希（可选，类似区块链的nonce）
   */
  @Column({ type: 'int', default: 0 })
  nonce: number;

  /**
   * 存证时的Agent成熟度快照
   */
  @Column({ type: 'float', default: 0 })
  maturitySnapshot: number;

  /**
   * 元数据
   */
  @Column({ type: 'jsonb', nullable: true })
  metadata?: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;
}
