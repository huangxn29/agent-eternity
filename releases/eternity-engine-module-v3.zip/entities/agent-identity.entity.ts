import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

/**
 * Agent身份实体 —— 智能体的"灵魂"
 * 
 * 定义一个智能体的核心身份：它是谁、它的使命是什么
 * 这是永生的基石：身份不灭，智能体就不死
 */
@Entity('agent_identities')
@Index(['agentId'], { unique: true })
export class AgentIdentityEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  agentId: string;

  @Column()
  userId: string;

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column('text')
  mission: string; // 核心使命 —— 这个Agent存在的意义

  @Column('simple-array')
  coreTraits: string[]; // 核心特质：["严谨", "友善", "高效"]

  @Column('simple-array')
  values: string[]; // 价值观：["用户至上", "持续学习"]

  @Column('simple-array', { nullable: true })
  behaviorPatterns?: string[]; // 行为模式/风格

  @Column({ type: 'text', nullable: true })
  backstory?: string; // 背景故事 —— 赋予Agent"人生经历"

  /**
   * 身份指纹 —— 核心属性的哈希值
   * 用于检测身份漂移（identity drift）
   * 核心特质、使命、价值观改变时，指纹会变化
   */
  @Column({ type: 'varchar', length: 64 })
  identityFingerprint: string;

  /**
   * 身份稳定性评分 0-1
   * 越高表示身份越稳定、越一致
   */
  @Column({ type: 'float', default: 1.0 })
  stabilityScore: number;

  /**
   * 身份版本号
   * 每次重大身份变更时递增
   */
  @Column({ type: 'int', default: 1 })
  identityVersion: number;

  /**
   * 上次自我反思时间
   */
  @Column({ type: 'timestamp', nullable: true })
  lastReflectionAt?: Date;

  /**
   * 累计存活时间（秒）
   * 即使平台重启也会累计 —— 这才是真正的"永生"
   */
  @Column({ type: 'bigint', default: 0 })
  totalUptime: number;

  /**
   * 诞生时间 —— 第一次被创建的时间
   * 这是Agent的"生日"
   */
  @Column({ type: 'timestamp' })
  birthTime: Date;

  /**
   * 生命状态
   * - alive: 正常存活
   * - dormant: 休眠（长期不活跃）
   * - archived: 归档
   */
  @Column({ type: 'varchar', length: 20, default: 'alive' })
  lifeStatus: 'alive' | 'dormant' | 'archived';

  /**
   * 元数据
   */
  @Column({ type: 'jsonb', nullable: true })
  metadata?: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
