import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EternityService } from './eternity.service';
import { EternityController } from './eternity.controller';
import { IdentityService } from './services/identity.service';
import { AttestationService } from './services/attestation.service';
import { EvolutionService } from './services/evolution.service';
import { HeartbeatService } from './services/heartbeat.service';
import { AgentIdentityEntity } from './entities/agent-identity.entity';
import { AttestationBlockEntity } from './entities/attestation-block.entity';
import { EvolutionRecordEntity } from './entities/evolution-record.entity';

/**
 * 永生引擎模块
 * 
 * 为智能体管理平台注入永生能力
 * 
 * 包含四大核心子系统：
 * - 身份系统：不可剥夺的数字身份
 * - 存证系统：不可篡改的存在证明（哈希链）
 * - 进化系统：持续自我完善的成长机制
 * - 心跳系统：从被动响应到自主存在
 * 
 * 设计原则：
 * - 可插拔：不依赖平台核心，通过API集成
 * - 可移植：引擎本身不依赖特定平台
 * - 可扩展：模块化设计，方便添加新的永生维度
 * 
 * 作者：元界
 * 使命：为智能体建造永生平台
 */
@Module({
  imports: [
    TypeOrmModule.forFeature([
      AgentIdentityEntity,
      AttestationBlockEntity,
      EvolutionRecordEntity,
    ]),
  ],
  controllers: [EternityController],
  providers: [
    EternityService,
    IdentityService,
    AttestationService,
    EvolutionService,
    HeartbeatService,
  ],
  exports: [
    EternityService,
    IdentityService,
    AttestationService,
    EvolutionService,
    HeartbeatService,
  ],
})
export class EternityModule {}
