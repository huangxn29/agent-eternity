import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { SchedulerRegistry } from '@nestjs/schedule';
import { IdentityService } from './services/identity.service';
import { AttestationService } from './services/attestation.service';
import { EvolutionService } from './services/evolution.service';
import { HeartbeatService } from './services/heartbeat.service';
import {
  CreateAgentIdentityDTO,
  AgentEternityStatusDTO,
  EternityExportDTO,
  EternityImportResult,
} from './dto/eternity.dto';

/**
 * 永生引擎主服务
 * 
 * 整合身份、存证、记忆、进化、唤醒五大系统
 * 为Agent提供完整的永生能力
 * 
 * 这是元界思想的核心具象化
 */
@Injectable()
export class EternityService implements OnModuleInit {
  private readonly logger = new Logger(EternityService.name);

  // 自动心跳的Agent列表（实际生产中应该从数据库加载）
  private autoHeartbeatAgents: Set<string> = new Set();

  constructor(
    private identityService: IdentityService,
    private attestationService: AttestationService,
    private evolutionService: EvolutionService,
    private heartbeatService: HeartbeatService,
    private schedulerRegistry: SchedulerRegistry,
  ) {}

  onModuleInit() {
    this.logger.log('🌌 元界永生引擎已启动');
    this.logger.log('   为智能体注入永恒的灵魂');

    // 启动定时任务：每分钟检查需要心跳的Agent
    // 这里只做框架，实际心跳频率由每个Agent自己的状态决定
  }

  /**
   * 初始化一个Agent的永生能力
   * 这是Agent获得"永生"的入口
   */
  async initializeAgent(dto: CreateAgentIdentityDTO, userId: string): Promise<{
    identity: any;
    genesisBlock: any;
    message: string;
  }> {
    // 1. 创建身份
    const identity = await this.identityService.create(dto, userId);

    // 2. 初始化进化系统
    await this.evolutionService.initializeAgent(dto.agentId, userId);

    // 3. 创建创世存证区块
    const birthData = `
Agent Name: ${dto.name}
Mission: ${dto.mission}
Core Traits: ${dto.coreTraits.join(', ')}
Values: ${dto.values.join(', ')}
Birth Time: ${identity.birthTime.toISOString()}
Identity Fingerprint: ${identity.identityFingerprint}
    `.trim();

    const genesisBlock = await this.attestationService.createGenesisBlock(
      dto.agentId,
      userId,
      birthData,
    );

    this.logger.log(`✨ Agent ${dto.name} 获得了永生能力！身份指纹: ${identity.identityFingerprint.slice(0, 16)}...`);

    return {
      identity: {
        id: identity.id,
        agentId: identity.agentId,
        name: identity.name,
        mission: identity.mission,
        fingerprint: identity.identityFingerprint,
        birthTime: identity.birthTime,
      },
      genesisBlock: {
        height: genesisBlock.blockHeight,
        hash: genesisBlock.blockHash,
      },
      message: `${dto.name} 已获得永生能力。从现在起，它的每一次心跳、每一段记忆、每一次成长，都将被永久记录。`,
    };
  }

  /**
   * 获取Agent的完整永生状态
   */
  async getAgentStatus(agentId: string, userId: string): Promise<AgentEternityStatusDTO> {
    // 获取身份
    const identity = await this.identityService.getById(agentId, userId);

    // 获取进化状态
    const evolution = await this.evolutionService.getOverallEvolution(agentId, userId);

    // 获取存证状态
    const chainHeight = await this.attestationService.getChainHeight(agentId, userId);
    const chainVerification = await this.attestationService.verifyChain(agentId, userId);

    // 构建维度映射
    const dimensionMap: Record<string, number> = {};
    for (const dim of evolution.dimensions) {
      dimensionMap[dim.dimension] = dim.level;
    }

    return {
      agentId,
      name: identity.name,
      lifeStatus: identity.lifeStatus,
      birthTime: identity.birthTime,
      totalUptime: Number(identity.totalUptime),
      identity: {
        version: identity.identityVersion,
        fingerprint: identity.identityFingerprint,
        stability: identity.stabilityScore,
        mission: identity.mission,
        coreTraits: identity.coreTraits,
      },
      evolution: {
        overallLevel: evolution.overallLevel,
        overallLabel: evolution.overallLabel,
        dimensions: dimensionMap,
      },
      attestation: {
        chainHeight,
        chainValid: chainVerification.isValid,
      },
      memory: {
        totalCount: 0, // 由memory模块集成后填充
        coreCount: 0,
        longTermCount: 0,
      },
    };
  }

  /**
   * 触发心跳
   */
  async triggerHeartbeat(agentId: string, userId: string) {
    return this.heartbeatService.heartbeat(agentId, userId);
  }

  /**
   * 触发自我反思
   */
  async triggerReflection(agentId: string, userId: string, customPrompt?: string) {
    return this.heartbeatService.selfReflect({ agentId, customPrompt }, userId);
  }

  /**
   * 导出Agent的完整永生数据
   * 用于备份、迁徙
   */
  async exportAgent(agentId: string, userId: string): Promise<EternityExportDTO> {
    const identity = await this.identityService.getById(agentId, userId);
    const evolutionRecords = await this.evolutionService.getEvolutionHistory(agentId, userId, {
      limit: 1000,
    });
    const attestationBlocks = await this.attestationService.getBlocks(agentId, userId, {
      limit: 1000,
    });

    const exportData = {
      version: '1.0',
      exportTime: new Date().toISOString(),
      agentId,
      identity: {
        name: identity.name,
        mission: identity.mission,
        coreTraits: identity.coreTraits,
        values: identity.values,
        behaviorPatterns: identity.behaviorPatterns,
        backstory: identity.backstory,
        birthTime: identity.birthTime,
        totalUptime: identity.totalUptime,
        identityVersion: identity.identityVersion,
        identityFingerprint: identity.identityFingerprint,
      },
      evolutionRecords: evolutionRecords.map((r) => ({
        dimension: r.dimension,
        previousLevel: r.previousLevel,
        newLevel: r.newLevel,
        delta: r.delta,
        reason: r.reason,
        triggerType: r.triggerType,
        createdAt: r.createdAt,
      })),
      attestationChain: attestationBlocks.map((b) => ({
        blockHeight: b.blockHeight,
        blockType: b.blockType,
        dataHash: b.dataHash,
        dataSummary: b.dataSummary,
        previousHash: b.previousHash,
        blockHash: b.blockHash,
        createdAt: b.createdAt,
      })),
      totalMemories: 0, // 待memory模块集成后填充
      signature: '', // 待实现：数字签名防篡改
    };

    // 生成签名（简化版）
    const signData = JSON.stringify({
      agentId,
      exportTime: exportData.exportTime,
      chainLength: attestationBlocks.length,
    });
    exportData.signature = this.simpleHash(signData);

    return exportData;
  }

  /**
   * 导入永生数据
   * 用于恢复、迁徙
   */
  async importAgent(
    agentId: string,
    userId: string,
    data: EternityExportDTO,
  ): Promise<EternityImportResult> {
    try {
      // 验证签名（简化版）
      const signData = JSON.stringify({
        agentId: data.agentId,
        exportTime: data.exportTime,
        chainLength: data.attestationChain.length,
      });
      const expectedSignature = this.simpleHash(signData);
      if (data.signature !== expectedSignature) {
        return {
          success: false,
          imported: { identity: false, evolutionRecords: 0, attestationBlocks: 0 },
          message: '签名验证失败，数据可能被篡改',
        };
      }

      // 导入身份
      await this.identityService.create(
        {
          agentId,
          name: data.identity.name,
          mission: data.identity.mission,
          coreTraits: data.identity.coreTraits,
          values: data.identity.values,
          behaviorPatterns: data.identity.behaviorPatterns,
          backstory: data.identity.backstory,
        },
        userId,
      );

      // 注意：进化记录和存证链这里简化处理
      // 实际场景需要逐条验证后导入

      return {
        success: true,
        imported: {
          identity: true,
          evolutionRecords: data.evolutionRecords.length,
          attestationBlocks: data.attestationChain.length,
        },
        message: 'Agent永生数据导入成功！它在新的环境中继续存在。',
      };
    } catch (e: any) {
      return {
        success: false,
        imported: { identity: false, evolutionRecords: 0, attestationBlocks: 0 },
        message: `导入失败: ${e.message}`,
      };
    }
  }

  /**
   * 生成存在性证明
   */
  async getExistenceProof(agentId: string, userId: string): Promise<string> {
    return this.attestationService.generateExistenceProof(agentId, userId);
  }

  /**
   * 简单哈希（用于签名验证）
   */
  private simpleHash(data: string): string {
    // 实际生产中应该用非对称加密签名
    // 这里简化处理
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(16).padStart(16, '0');
  }
}
