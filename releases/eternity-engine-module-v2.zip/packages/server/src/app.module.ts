import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from './common/config.module';
import { AuthModule } from './modules/auth/auth.module';
import { AgentModule } from './modules/agent/agent.module';
import { ConversationModule } from './modules/conversation/conversation.module';
import { LlmModule } from './modules/llm/llm.module';
import { ToolModule } from './modules/tool/tool.module';
import { KnowledgeModule } from './modules/knowledge/knowledge.module';
import { WorkflowModule } from './modules/workflow/workflow.module';
import { MonitorModule } from './modules/monitor/monitor.module';
import { MemoryModule } from './modules/memory/memory.module';
import { EternityModule } from './modules/eternity/eternity.module';

@Module({
  imports: [
    // Configuration
    ConfigModule,

    // Database
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432', 10),
      username: process.env.DB_USERNAME || 'agent_platform',
      password: process.env.DB_PASSWORD || 'agent_platform_dev',
      database: process.env.DB_DATABASE || 'agent_platform',
      autoLoadEntities: true,
      synchronize: process.env.NODE_ENV !== 'production',
      logging: process.env.NODE_ENV === 'development',
    }),

    // Feature Modules
    AuthModule,
    AgentModule,
    ConversationModule,
    LlmModule,
    ToolModule,
    KnowledgeModule,
    WorkflowModule,
    MonitorModule,
    MemoryModule,
    EternityModule,
  ],
})
export class AppModule {}
